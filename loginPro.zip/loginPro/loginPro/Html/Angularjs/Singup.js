﻿


'use strict';
var signUpApp = angular.module('signUpApp', []);

signUpApp.controller('signupController', ['$scope', '$window', 'signUpService',
function ($scope, $window, signUpService) {

    $scope.init = function () {
        $scope.isProcessing = false;
    
    };

    $scope.init();

    $scope.registration = {
        Email: "",
        Password: ""
        
    };

    $scope.signUp = function () {
        $scope.isProcessing = true;
        $scope.RegisterBtnText = "Please wait...";
        signUpService.saveRegistration($scope.registration).then(function (response) {
            alert("Registration Successfully Completed. Please sign in to Continue.");
            $window.location.href = "SingIn.html";
        }, function () {
            alert("Error occured. Please try again.");
            $scope.isProcessing = false;
           
        });
    };

}]);

signUpApp.factory('signUpService', ['$http', function ($http) {

    var signUpServiceFactory = {};

    signUpServiceFactory.saveRegistration = function (registration) {
        return $http.post('/api/login/Singup', registration)
    };

    return signUpServiceFactory;
}]);
