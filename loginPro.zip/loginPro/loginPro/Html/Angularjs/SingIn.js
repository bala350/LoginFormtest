﻿/// <reference path="angular.js" />
var loginApp = angular.module('loginApp', []);



loginApp.controller('loginController', ['$scope', '$window', 'signInApp', function ($scope, $window, signInApp) {
    $scope.init = function () {
        $scope.isProcessing = false;
       
    }

    $scope.init();

    $scope.loginData = {
        Name: "",
        password: ""
    }

    $scope.Login = function () {
        $scope.isProcessing = true;
        authService.login($scope.loginData).then(function (response) {
            alert("Login Successfully");
            $window.location.href = "ALL.html";
        }, function () {
            alert("Failed.Please try again.");
            $scope.init();
        })
    }

}])

signInApp.factory('signInService', ['$http', function ($http) {

    var signInServiceFactory = {};

    signInServiceFactory.Login = function (login) {
        return $http.post('/api/login/singin', login)
    };

    return signINServiceFactory;
}]);