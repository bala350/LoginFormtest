﻿


'use strict';
var updateApp = angular.module('updateApp', []);

updateApp.controller('UpdateController', ['$scope', '$window', 'signUpService',
function ($scope, $window, signUpService) {

    $scope.init = function () {
        $scope.isProcessing = false;

    };

    $scope.init();

    $scope.registration = {
        Name:"",
        Email: "",
        Password: ""
       
    };

    $scope.Update = function () {
        $scope.isProcessing = true;
        
        updateService.saveupdate($scope.registration).then(function (response) {
            alert("Updated Successfully ");
            $window.location.href = "ALL.html";
        }, function () {
            alert("Error occured. Please try again.");
            $scope.isProcessing = false;

        });
    };

}]);

updateApp.factory('updateService', ['$http', function ($http) {

    var signUpServiceFactory = {};

    updateServiceFactory.saveupdate = function (registration) {
        return $http.post('/api/login/Singup', registration)
    };

    return updateServiceFactory;
}]);
