﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using loginPro.Models;
using System.Data;
using System.Data.SqlClient;

namespace loginPro.Models
{
    public class dboperation
    {
        public Connection conString = new Connection();
        public bool Login(string firstname, string password)
        {

            try
            {
                Login log = new Login();
                SqlConnection Sqlcon = new SqlConnection(conString.connString);
                SqlCommand Sqlcmd = new SqlCommand("Sp_login", Sqlcon);
                Sqlcmd.CommandType = CommandType.StoredProcedure;

                Sqlcmd.Parameters.AddWithValue("@uId", firstname);
                Sqlcmd.Parameters.AddWithValue("@UPassword", password);

                Sqlcon.Open();
                SqlDataReader Reader = Sqlcmd.ExecuteReader();
                if (Reader.Read())
                {
                    log.Name = Reader["Name"].ToString();
                    log.Password = Reader["Password"].ToString();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {

                //throw;
            }
            return false;
        }



        internal List<Login> Singin()
        {
            List<Login> objlist = new List<Login>();
            try
            {
               
                SqlConnection SqlCon = new SqlConnection(conString.connString);
                SqlCommand cmd = new SqlCommand("Sp_login", SqlCon);
                SqlCon.Open();
                SqlDataReader readar = cmd.ExecuteReader();

                while (readar.Read())
                {
                    try
                    {
                        Login obj = new Login();

                        obj.Email = readar["Email"].ToString();
                        obj.Password = readar["Password"].ToString();
                       
                        objlist.Add(obj);
                    }
                    catch (Exception objEx)
                    {

                    }

                }
            }

            catch (Exception objEx)
            {

            }
            return objlist;
        }



        internal void Add(Login obj)
        {
            try
            {
                // Login obj = new Login();
                SqlConnection SqlCon = new SqlConnection(conString.connString);
                SqlCommand cmd = new SqlCommand("sp_insert", SqlCon);//use storeprocedure
                SqlCon.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Name", obj.Name);
                cmd.Parameters.AddWithValue("@Email", obj.Email);
                cmd.Parameters.AddWithValue("@Password", obj.Password);

                cmd.ExecuteNonQuery();




            }
            catch (Exception ex)
            {

                throw;
            }
        }


        public DataSet get_record()
        {
            SqlConnection SqlCon = new SqlConnection(conString.connString);
            SqlCommand com = new SqlCommand("Sp_login_get", SqlCon);

            com.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter da = new SqlDataAdapter(com);

            DataSet ds = new DataSet();

            da.Fill(ds);

            return ds;

        }


        public DataSet get_login_byid(int id)
        {
            SqlConnection SqlCon = new SqlConnection(conString.connString);
            SqlCommand com = new SqlCommand("Sp_login_byid", SqlCon);

            com.CommandType = CommandType.StoredProcedure;

            com.Parameters.AddWithValue("@ID", id);

            SqlDataAdapter da = new SqlDataAdapter(com);

            DataSet ds = new DataSet();

            da.Fill(ds);

            return ds;

        }


        public void deletedata(int id)
        {
            SqlConnection SqlCon = new SqlConnection(conString.connString);
            SqlCommand com = new SqlCommand("Sp_register_delete", SqlCon);

            com.CommandType = CommandType.StoredProcedure;

            com.Parameters.AddWithValue("@Sr_no", id);

            SqlCon.Open();

            com.ExecuteNonQuery();

            SqlCon.Close();

        }


        public void update_login(Login rs)
        {
            SqlConnection SqlCon = new SqlConnection(conString.connString);
            SqlCommand com = new SqlCommand("Sp_login_Update", SqlCon);

            com.CommandType = CommandType.StoredProcedure;


            com.Parameters.AddWithValue("@Name", rs.Name);

            com.Parameters.AddWithValue("@Email", rs.Email);

            com.Parameters.AddWithValue("@Password", rs.Password);
;


            SqlCon.Open();

            com.ExecuteNonQuery();

            SqlCon.Close();

        }







    }
}