﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace loginPro.Models
{
    public class Connection
    {
        public string connString = @"Server=DESKTOP-3E97MFV\SQLEXPRESS;Database=test;Integrated Security=True";
    }
}