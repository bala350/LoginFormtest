﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using loginPro.Models;
using System.Data;
using System.Data.SqlClient;

namespace loginPro.Controllers
{
    public class LoginController : ApiController
    {
        public Connection conString = new Connection();
        // GET api/login
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/login/5
        public string Get(int id)
        {
            return "value";
        }

        [HttpPost]
        [Route("api/login/singin")]
        public bool singin(string name,string password)
        {
            try
            {
                dboperation Db = new dboperation();
                Db.Login(name, password);
                return Db.Login(name, password);
            }
            catch (Exception ex)
            { 
                
                throw;
            }
            

             //return Db.Login(name,password);

        }



        // POST api/login
        [HttpPost]
        [Route("api/login/Singup")]
        public void Singup([FromBody]Login obj)
        {
            try
            {

                dboperation objDB = new dboperation();
                objDB.Add(obj);


            }
            catch (Exception ex)
            {

                throw;
            }
        }

        [HttpGet]
        [Route("api/login/Get_data")]
        public DataSet Get_data()
        {
            dboperation objDB = new dboperation();
            DataSet ds = objDB.get_record();

            List<Login> listrs = new List<Login>();

            foreach (DataRow dr in ds.Tables[0].Rows)
            {

                listrs.Add(new Login

                {

                    ID = Convert.ToInt32(dr["ID"]),
                    Name = dr["Name"].ToString(),

                    Email = dr["Email"].ToString(),

                    Password = dr["Password"].ToString()

                    


                });

            }

            return ds;

        }


        [HttpGet]
        [Route("api/login/Get_loginbyid")]
        public DataSet Get_loginbyid(int id)
        {
            dboperation objDB = new dboperation();
            DataSet ds = objDB.get_login_byid(id);

            List<Login> listrs = new List<Login>();

            foreach (DataRow dr in ds.Tables[0].Rows)
            {

                listrs.Add(new Login

                {

                    ID = Convert.ToInt32(dr["ID"]),
                    Name = dr["Name"].ToString(),

                    Email = dr["Email"].ToString(),

                    Password = dr["Password"].ToString()

                });

            }

            return ds;

        }

        [HttpGet]
        [Route("api/login/delete_record")]
        public void delete_record(int id)
        {

            dboperation objDB = new dboperation();
            string res = string.Empty;

            try
            {

                objDB.deletedata(id);

                res = "data deleted";

            }

            catch (Exception ex)
            {

                res = "failed";

            }

           
        }

        [HttpPost]
        [Route("api/login/update_record")]
        public void update_record(Login rs)
        {
            dboperation objDB = new dboperation();
            string res = string.Empty;

            try
            {

                objDB.update_login(rs);

                res = "Updated";

            }

            catch (Exception)
            {

                res = "failed";

            }

            



        }


        // PUT api/login/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/login/5
        public void Delete(int id)
        {
        }
    }
}
